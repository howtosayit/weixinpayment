---
name: wechat-payment
description: "This skill provides complete guidance for integrating WeChat Pay JSAPI into WeChat Mini Programs. It should be used when the user needs to implement payment functionality subscriptions, one-time purchases, virtual goods in a WeChat Mini Program, or when troubleshooting WeChat Pay integration issues. Covers wx.requestPayment, backend unifiedOrder plus signing for Spring Boot and Node.js and PHP, platform configuration requirements, and common error resolution."
agent_created: true
---

# 微信小程序 JSAPI 微信支付 Skill

> **支付接口**：`wx.requestPayment`（JSAPI 标准微信支付）  
> **适用**：会员订阅、课程购买、道具购买等所有虚拟商品支付

---

## 平台配置清单

实现支付前，需从微信平台获取以下配置：

| 配置项 | 获取位置 | 用途 |
|--------|----------|------|
| 小程序 AppID | 微信公众平台 → 开发管理 → 开发设置 | code2session、统一下单 |
| 小程序 AppSecret | 同上 | code 换 openid |
| 商户号 mchId | 微信支付商户平台 → 账户中心 → 商户信息 | 统一下单 |
| APIv2 密钥（32位） | 微信支付商户平台 → 账户中心 → API安全 → 设置API密钥 | 签名 & 验签 |
| 支付回调地址 | 自有服务器的 HTTPS 地址 | 微信异步通知 |

---

## 支付流程

```
用户点击支付 → 前端 wx.login() 获取 code
  → POST /api/payment/create (传 code + 商品信息)
  → 后端 code2session → openid
  → 后端 unifiedOrder → prepay_id
  → 后端 二次签名 → timeStamp / nonceStr / package / signType / paySign
  → 前端 wx.requestPayment({ timeStamp, nonceStr, package, signType, paySign })
  → 微信弹出密码框 → 用户输入密码 → 成功/取消
```

---

## 后端代码

### Java 工具类（核心）

```java
import cn.hutool.crypto.digest.DigestUtil;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class WechatPayUtil {

    private final String appId;
    private final String mchId;
    private final String apiKey;
    private final String notifyUrl;

    public WechatPayUtil(String appId, String mchId, String apiKey, String notifyUrl) {
        this.appId = appId;
        this.mchId = mchId;
        this.apiKey = apiKey;
        this.notifyUrl = notifyUrl;
    }

    // ---------- code2session ----------

    public String code2openid(String secret, String code) {
        String url = "https://api.weixin.qq.com/sns/jscode2session"
                + "?appid=" + appId + "&secret=" + secret
                + "&js_code=" + code + "&grant_type=authorization_code";
        String resp = httpGet(url);
        JSONObject json = JSON.parseObject(resp);
        return json.getString("openid");
    }

    // ---------- 统一下单 ----------

    public String unifiedOrder(String openid, String outTradeNo, int totalFee, String body) {
        Map<String, String> params = new TreeMap<>();
        params.put("appid", appId);
        params.put("mch_id", mchId);
        params.put("nonce_str", UUID.randomUUID().toString().replace("-", ""));
        params.put("body", body);
        params.put("out_trade_no", outTradeNo);
        params.put("total_fee", String.valueOf(totalFee));
        params.put("spbill_create_ip", "127.0.0.1");
        params.put("notify_url", notifyUrl);
        params.put("trade_type", "JSAPI");
        params.put("openid", openid);
        params.put("sign", sign(params));

        String xml = mapToXml(params);
        String respXml = httpPostXml("https://api.mch.weixin.qq.com/pay/unifiedorder", xml);
        Map<String, String> resp = xmlToMap(respXml);
        if ("SUCCESS".equals(resp.get("return_code"))
                && "SUCCESS".equals(resp.get("result_code"))) {
            return resp.get("prepay_id");
        }
        return null;
    }

    // ---------- 生成前端支付参数 ----------

    public Map<String, String> buildPaymentParams(String prepayId) {
        String timeStamp = String.valueOf(System.currentTimeMillis() / 1000);
        String nonceStr = UUID.randomUUID().toString().replace("-", "");
        String packageStr = "prepay_id=" + prepayId;
        String signType = "MD5";

        String signStr = "appId=" + appId
                + "&nonceStr=" + nonceStr
                + "&package=" + packageStr
                + "&signType=" + signType
                + "&timeStamp=" + timeStamp
                + "&key=" + apiKey;
        String paySign = md5(signStr).toUpperCase();

        Map<String, String> result = new LinkedHashMap<>();
        result.put("timeStamp", timeStamp);
        result.put("nonceStr", nonceStr);
        result.put("packageStr", packageStr);
        result.put("signType", signType);
        result.put("paySign", paySign);
        return result;
    }

    // ---------- 回调验签 ----------

    public boolean verifyCallbackSign(Map<String, String> params) {
        String received = params.get("sign");
        if (received == null) return false;
        Map<String, String> copy = new TreeMap<>(params);
        copy.remove("sign");
        return received.equals(sign(copy));
    }

    // ---------- 内部工具 ----------

    private String sign(Map<String, String> params) {
        StringBuilder sb = new StringBuilder();
        params.forEach((k, v) -> {
            if (v != null && !v.isEmpty() && !"sign".equals(k))
                sb.append(k).append("=").append(v).append("&");
        });
        sb.append("key=").append(apiKey);
        return md5(sb.toString()).toUpperCase();
    }

    private String md5(String s) {
        return DigestUtil.md5Hex(s, StandardCharsets.UTF_8);
    }

    private String mapToXml(Map<String, String> p) {
        StringBuilder sb = new StringBuilder("<xml>");
        p.forEach((k, v) -> sb.append("<").append(k).append("><![CDATA[")
                .append(v).append("]]></").append(k).append(">"));
        return sb.append("</xml>").toString();
    }

    private Map<String, String> xmlToMap(String xml) {
        Map<String, String> m = new LinkedHashMap<>();
        Matcher mt = Pattern.compile("<(\\w+)><!\\[CDATA\\[(.*?)\\]\\]></\\1>").matcher(xml);
        while (mt.find()) m.put(mt.group(1), mt.group(2));
        return m;
    }
}
```

### Java 支付接口（Controller）

```java
@PostMapping("/api/payment/create")
public Result createPayment(
        @RequestParam String userId,
        @RequestParam String productType,
        @RequestParam BigDecimal amount,
        @RequestParam String code) {

    // 1. code → openid
    String openid = wechatPayUtil.code2openid("你的AppSecret", code);
    if (openid == null) return Result.error("获取openid失败");

    // 2. 生成订单号
    String orderNo = "ORDER" + System.currentTimeMillis()
            + UUID.randomUUID().toString().substring(0, 8);

    // 3. 金额：元 → 分
    int totalFee = amount.multiply(BigDecimal.valueOf(100)).intValue();

    // 4. 订单入库（status: pending）
    // saveOrderToDatabase(orderNo, userId, productType, amount, "pending");

    // 5. 统一下单
    String prepayId = wechatPayUtil.unifiedOrder(openid, orderNo, totalFee, "商品描述");
    if (prepayId == null) return Result.error("统一下单失败");

    // 6. 生成支付参数
    Map<String, String> payParams = wechatPayUtil.buildPaymentParams(prepayId);
    payParams.put("orderNo", orderNo);
    return Result.success(payParams);
}


// ===== 支付回调（前端 success 后调用） =====
@PostMapping("/api/payment/callback")
public Result callback(@RequestParam String orderNo,
                       @RequestParam String status) {
    // 更新订单、开通会员/发货
    // updateOrder(orderNo, status);
    return Result.success();
}


// ===== 微信异步通知（微信服务器 → 你的服务器） =====
@PostMapping("/api/payment/wx-notify")
public void wxNotify(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    // 1. 读取 XML body
    StringBuilder xml = new StringBuilder();
    try (BufferedReader r = req.getReader()) {
        String line; while ((line = r.readLine()) != null) xml.append(line);
    }

    // 2. 验签
    Map<String, String> params = xmlToMap(xml.toString());
    if (!wechatPayUtil.verifyCallbackSign(params)) {
        resp.getWriter().write("<xml><return_code><![CDATA[FAIL]]></return_code></xml>");
        return;
    }

    // 3. 处理（幂等）
    String orderNo = params.get("out_trade_no");
    String transactionId = params.get("transaction_id");
    // 更新订单 + 发货/开通会员...

    // 4. 必须返回 SUCCESS
    resp.getWriter().write("<xml><return_code><![CDATA[SUCCESS]]></return_code></xml>");
}
```

### Node.js 工具类

```javascript
const crypto = require('crypto');

class WechatPay {
    constructor({ appId, mchId, apiKey, notifyUrl }) {
        Object.assign(this, { appId, mchId, apiKey, notifyUrl });
    }

    md5(s) { return crypto.createHash('md5').update(s, 'utf8').digest('hex'); }

    nonce() { return crypto.randomUUID().replace(/-/g, ''); }

    sign(params) {
        const str = Object.keys(params)
            .filter(k => k !== 'sign' && params[k])
            .sort().map(k => `${k}=${params[k]}`).join('&');
        return this.md5(`${str}&key=${this.apiKey}`).toUpperCase();
    }

    async code2openid(secret, code) {
        const url = `https://api.weixin.qq.com/sns/jscode2session?appid=${this.appId}&secret=${secret}&js_code=${code}&grant_type=authorization_code`;
        const { data } = await fetch(url).then(r => r.json());
        return data.openid || null;
    }

    async unifiedOrder(openid, outTradeNo, totalFee, body) {
        const params = {
            appid: this.appId, mch_id: this.mchId, nonce_str: this.nonce(),
            body, out_trade_no: outTradeNo, total_fee: String(totalFee),
            spbill_create_ip: '127.0.0.1', notify_url: this.notifyUrl,
            trade_type: 'JSAPI', openid
        };
        params.sign = this.sign(params);

        const xml = '<xml>' + Object.entries(params)
            .map(([k, v]) => `<${k}><![CDATA[${v}]]></${k}>`).join('') + '</xml>';

        const resp = await fetch('https://api.mch.weixin.qq.com/pay/unifiedorder', {
            method: 'POST', body: xml,
            headers: { 'Content-Type': 'text/xml' }
        }).then(r => r.text());

        const get = (tag) => (resp.match(new RegExp(`<${tag}><!\\[CDATA\\[(.*?)\\]\\]></${tag}>`)) || [])[1];
        return get('return_code') === 'SUCCESS' && get('result_code') === 'SUCCESS'
            ? get('prepay_id') : null;
    }

    buildPaymentParams(prepayId) {
        const timeStamp = String(Math.floor(Date.now() / 1000));
        const nonceStr = this.nonce();
        const packageStr = `prepay_id=${prepayId}`;
        const signType = 'MD5';
        const paySign = this.md5(
            `appId=${this.appId}&nonceStr=${nonceStr}&package=${packageStr}&signType=${signType}&timeStamp=${timeStamp}&key=${this.apiKey}`
        ).toUpperCase();
        return { timeStamp, nonceStr, packageStr, signType, paySign };
    }
}
```

### PHP 工具类

```php
class WechatPay {
    private $appId, $secret, $mchId, $apiKey, $notifyUrl;

    public function __construct($appId, $secret, $mchId, $apiKey, $notifyUrl) {
        $this->appId = $appId; $this->secret = $secret;
        $this->mchId = $mchId; $this->apiKey = $apiKey;
        $this->notifyUrl = $notifyUrl;
    }

    public function code2openid($code) {
        $url = "https://api.weixin.qq.com/sns/jscode2session?appid={$this->appId}&secret={$this->secret}&js_code={$code}&grant_type=authorization_code";
        $resp = json_decode(file_get_contents($url), true);
        return $resp['openid'] ?? null;
    }

    public function unifiedOrder($openid, $outTradeNo, $totalFee, $body) {
        $params = [
            'appid' => $this->appId, 'mch_id' => $this->mchId,
            'nonce_str' => $this->nonce(), 'body' => $body,
            'out_trade_no' => $outTradeNo, 'total_fee' => (string)$totalFee,
            'spbill_create_ip' => '127.0.0.1', 'notify_url' => $this->notifyUrl,
            'trade_type' => 'JSAPI', 'openid' => $openid,
        ];
        $params['sign'] = $this->sign($params);
        $xml = $this->toXml($params);
        $respXml = $this->httpPost('https://api.mch.weixin.qq.com/pay/unifiedorder', $xml);
        $resp = $this->fromXml($respXml);
        return ($resp['return_code']??'') === 'SUCCESS' && ($resp['result_code']??'') === 'SUCCESS'
            ? $resp['prepay_id'] : null;
    }

    public function buildPaymentParams($prepayId) {
        $params = [
            'appId' => $this->appId, 'timeStamp' => (string)time(),
            'nonceStr' => $this->nonce(), 'package' => "prepay_id={$prepayId}",
            'signType' => 'MD5',
        ];
        $params['paySign'] = $this->sign($params);
        return $params;
    }

    private function sign($p) { ksort($p); $s='';
        foreach($p as $k=>$v) if($v!==''&&$v!==null&&$k!=='sign') $s.="$k=$v&";
        return strtoupper(md5($s.'key='.$this->apiKey)); }

    private function nonce() { return bin2hex(random_bytes(16)); }
    private function toXml($a) { $x='<xml>'; foreach($a as $k=>$v) $x.="<{$k}><![CDATA[{$v}]]></{$k}>"; return $x.'</xml>'; }
    private function fromXml($x) { preg_match_all('/<(\w+)><!\[CDATA\[(.*?)\]\]><\/\1>/s',$x,$m); return array_combine($m[1],$m[2]); }
}
```

---

## 前端代码

```javascript
Page({
    handlePay() {
        const that = this;
        const userId = wx.getStorageSync('userId');
        if (!userId) { wx.showToast({ title: '请先登录', icon: 'none' }); return; }

        wx.showLoading({ title: '创建订单...', mask: true });

        // 每次支付前重新 wx.login，code 只能用一次
        wx.login({
            success(res) {
                if (!res.code) { wx.hideLoading(); return; }

                wx.request({
                    url: 'https://你的域名/api/payment/create',
                    method: 'POST',
                    data: { userId, productType: 'month', amount: 0.01, code: res.code },
                    success(resp) {
                        wx.hideLoading();
                        const data = resp.data.data || resp.data;
                        if (!data || !data.timeStamp) {
                            wx.showModal({ title: '支付异常', content: '创建订单失败', showCancel: false });
                            return;
                        }

                        wx.requestPayment({
                            timeStamp: data.timeStamp,
                            nonceStr: data.nonceStr,
                            package: data.packageStr,     // 后端字段 packageStr → 前端参数 package
                            signType: data.signType,
                            paySign: data.paySign,
                            success() {
                                // 通知后端
                                wx.request({
                                    url: 'https://你的域名/api/payment/callback',
                                    method: 'POST',
                                    data: { orderNo: data.orderNo, status: 'success' }
                                });
                                wx.showToast({ title: '支付成功！', icon: 'success' });
                            },
                            fail(err) {
                                const msg = err.errMsg || '';
                                if (msg.indexOf('cancel') > -1)
                                    wx.showToast({ title: '已取消', icon: 'none' });
                                else
                                    wx.showModal({ title: '支付失败', content: msg, showCancel: false });
                            }
                        });
                    },
                    fail() { wx.hideLoading(); wx.showToast({ title: '网络错误', icon: 'none' }); }
                });
            }
        });
    }
});
```

---

## SQL 建表

```sql
CREATE TABLE `payment` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `order_no` VARCHAR(64) NOT NULL,
    `user_id` BIGINT NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `product_type` VARCHAR(20),
    `status` VARCHAR(20) DEFAULT 'pending',
    `transaction_id` VARCHAR(64),
    `paid_at` DATETIME,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY (`order_no`),
    KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## wx.requestPayment 参数对照

| 前端参数 | 后端字段 | 说明 |
|----------|----------|------|
| `timeStamp` | `timeStamp` | 秒级时间戳字符串 |
| `nonceStr` | `nonceStr` | 随机串 |
| `package` | `packageStr` | `prepay_id=xxx`，注意 package 是 JS 保留字 |
| `signType` | `signType` | `MD5` |
| `paySign` | `paySign` | 二次签名 |

---

## 错误排查

| 错误 | 原因 |
|------|------|
| `requestPayment:fail cancel` | 用户取消，正常 |
| `requestPayment:fail sign error` | paySign 签名错误，检查签名顺序和 apiKey |
| `appid and mch_id not match` | 小程序未关联商户号 |
| `total_fee invalid` | 金额必须是正整数的分 |
| 统一下单 FAIL | openid/金额/参数错误 |

---

## 上线检查

- [ ] `api.weixin.qq.com`、`api.mch.weixin.qq.com`、你的 API 域名加入 request 合法域名
- [ ] 全部 HTTPS
- [ ] 商户号已关联小程序 AppID
- [ ] APIv2 密钥已设置（32位）
- [ ] 支付回调地址公网可达
- [ ] 隐私协议声明支付信息用途
